// {Name: Buckman_1_Data}
// {Description: Buckman Data}
// {Visibility: Admin}

project.customers = [
    {
        "id": "0000203123",
        "name": "Pensacola"
    }
];

project.products = [
    {
        "id": 1,
        "name": "Bubreak 4452T",
        "container": "tanker truck"
    },
    {
        "id": 2,
        "name": "Bubreak 4484",
        "container": "tote"
    },
    {
        "id": 3,
        "name": "Bubreak 4484",
        "container": "tanker truck"
    },
    {
        "id": 4,
        "name": "Bubreak 4528",
        "container": "tote"
    },
    {
        "id": 5,
        "name": "Bubreak 4528",
        "container": "tanker truck"
    },
    {
        "id": 6,
        "name": "Bubreak 4580",
        "container": "tote"
    },
    {
        "id": 7,
        "name": "Bubreak 4580",
        "container": "tanker truck"
    },
    {
        "id": 8,
        "name": "Buflock 594",
        "container": "tote"
    },
    {
        "id": 9,
        "name": "Buflock 594",
        "container": "tanker truck"
    },
    {
        "id": 10,
        "name": "Bulab 2121",
        "container": "tote"
    },
    {
        "id": 11,
        "name": "Bulab 4523",
        "container": "tanker truck"
    },
    {
        "id": 12,
        "name": "Bulab 4441",
        "container": "tote"
    },
    {
        "id": 13,
        "name": "BSI 88",
        "container": "tanker truck"
    },
    {
        "id": 14,
        "name": "Busan 1078",
        "container": "tote"
    },
    {
        "id": 15,
        "name": "Busperse 2036",
        "container": "tanker truck"
    },
    {
        "id": 16,
        "name": "Busperse 2505",
        "container": "tote"
    }
];
